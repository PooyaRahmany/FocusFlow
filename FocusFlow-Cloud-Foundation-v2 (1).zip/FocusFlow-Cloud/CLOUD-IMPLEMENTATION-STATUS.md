# FocusFlow Cloud — implementation status

Date: 2026-11-11
Base: `FocusFlow-Cloud-Foundation.zip` supplied for this revision

## Product target retained

- Authentication: email/password plus Google OAuth.
- Sync: automatic and bidirectional.
- Shared data: supported user-owned data, excluding large bundled media files.

## Completed in this revision

- Preserved the existing HTML/CSS/JS application and original assets.
- Fixed LocalStorage-to-IndexedDB snapshot replacement: old rows are removed and the full new snapshot is inserted after cursor traversal completes.
- Made the mirror queue recover after a failed flush rather than leaving the promise chain permanently rejected.
- Hardened `sync_records`: authenticated clients retain read access, while direct insert/update/delete paths are revoked.
- Changed the version-checked write RPC to `SECURITY DEFINER`; it validates `auth.uid()`, uses a fixed search path, and scopes operations by the authenticated user.
- Added a forward migration (`202611110001_harden_sync_record_writes.sql`) for databases where the initial migration was already applied.
- Kept the initial migration aligned with the hardened permissions for fresh installations.

## Not completed / not verified

- Supabase project is not connected; migrations have not been executed against a live database.
- Email/password and Google OAuth flows are not enabled.
- No real remote synchronization, Realtime subscription, device revocation, or cloud backup is active.
- IndexedDB remains a mirror/snapshot; application repositories have not been switched from LocalStorage.
- PromptVault keeps its existing separate IndexedDB store and is not included in the new mirror.
- Real-browser IndexedDB regression, Service Worker installation, offline reload, and PWA installation could not be completed in this environment.

## Required next steps

1. Back up the current Supabase project before applying migrations.
2. Apply `202611110001_harden_sync_record_writes.sql` to an existing project, or apply both migrations in order to a fresh project.
3. Run two-account RLS tests and verify that direct writes to `sync_records` fail while the RPC succeeds for the owner only.
4. Run browser regression tests for mirror updates, deletes/tombstones, offline use, and the existing application flows.
5. Only then begin authentication and repository migration.

Do not upload local data or claim cloud sync is operational until the live Supabase setup and browser/two-account tests pass.
