# FocusFlow Cloud Foundation v2

Date: 2026-11-11

## Changes

### IndexedDB mirror
- Fixed replacement of normalized rows after a LocalStorage key changes. Existing cursor rows are now deleted before the replacement snapshot is inserted at cursor exhaustion.
- Kept deletion as tombstones.
- Recovered the mirror promise queue after a rejected flush.

### Supabase security
- Removed direct insert/update policies for `sync_records`.
- Revoked direct write privileges from `authenticated`; retained select access subject to RLS.
- Made `apply_focusflow_sync_operation` a `SECURITY DEFINER` function. It checks `auth.uid()`, validates collection and record ID, and uses a fixed `search_path`.
- Added a forward migration for databases that already ran the original migration.

### PWA
- Bumped the Service Worker cache version to invalidate the previous shell cache after the foundation code update.

## Important

This revision does not implement authentication or cloud synchronization. Apply the forward migration to an existing Supabase project, then perform live database and browser tests before enabling uploads.
