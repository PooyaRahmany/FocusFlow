# گزارش ممیزی فنی FocusFlow — Phase 0

**مبنای بررسی:** آرشیو بارگذاری‌شده `FocusFlow-main.rar`  
**دامنه:** بررسی ساختار، فناوری‌ها، قابلیت‌های موجود، ذخیره‌سازی، طراحی بصری، وابستگی‌ها و آمادگی برای معماری Offline-First / Cloud  
**وضعیت تغییر کد:** هیچ فایل اصلی پروژه ویرایش نشده است.

---

## 1. خلاصه مدیریتی

FocusFlow در نسخه فعلی یک **وب‌اپلیکیشن تک‌صفحه‌ای (SPA) استاتیک و سمت‌کاربر** با HTML، CSS و JavaScript است. پروژه به بک‌اند یا سرویس احراز هویت متصل نیست. بخش اصلی داده‌ها در `localStorage` نگهداری می‌شوند و تنها کتابخانه Bonfire / PromptVault از `IndexedDB` استفاده می‌کند؛ آن بخش نیز برای شرایط عدم دسترسی به IndexedDB مسیر جایگزین `localStorage` دارد.

پروژه از نظر حفظ ظاهر و تبدیل تدریجی به معماری ابری، نقطه شروع مناسبی دارد: دارایی‌های اصلی محلی‌اند، ساختار صفحه قابل استفاده است و برنامه برای اجرا به مرحله Build پیچیده‌ای وابسته نیست. با این حال، معماری فعلی هنوز Offline-First واقعی یا PWA کامل نیست؛ وجود داده محلی به‌تنهایی به معنی کش تضمین‌شده App Shell، صف عملیات آفلاین یا همگام‌سازی نیست.

**نتیجه اصلی:** لازم نیست FocusFlow از صفر بازنویسی شود. بهتر است UI، فایل‌های طراحی، منطق فعلی و کلیدهای قدیمی ذخیره‌سازی حفظ شوند و یک لایه Repository / Local Database / Cloud Sync به‌صورت تدریجی به آن‌ها اضافه شود.

## 2. ساختار واقعی آرشیو

آرشیو ۱۳۱ ورودی دارد و پس از استخراج، ۱۲۲ فایل معمولی در مسیر داخلی `FocusFlow-main/FocusFlow-main/` به دست آمد.

| بخش | تعداد / اندازه تقریبی |
|---|---:|
| `index.html` | ۱ فایل، ۱۵۶ کیلوبایت |
| CSS | ۶ فایل، مجموع حدود ۴۵۶ کیلوبایت |
| JavaScript | ۴۶ فایل، مجموع حدود ۹۵۷ کیلوبایت |
| رسانه | ۵۹ فایل، مجموع حدود ۹٫۷۵ مگابایت |
| فونت | ۲ فایل WOFF2، مجموع حدود ۸۴ کیلوبایت |
| مستندات و تنظیمات | README، گزارش کیفیت، Asset Manifest، تنظیمات Lighthouse و GitHub Actions |

پوشه‌های اصلی:

```text
FocusFlow-main/
├── index.html
├── README.md
├── QUALITY-REPORT.md
├── ASSET-MANIFEST.json
├── .gitignore
├── .nojekyll
├── .lighthouserc.desktop.json
├── .lighthouserc.mobile.json
├── .github/workflows/lighthouse.yml
└── assets/
    ├── css/       # شش فایل استایل
    ├── fonts/     # دو فونت WOFF2
    ├── js/        # چهل‌وشش فایل JavaScript
    └── media/     # پنجاه‌ونه فایل SVG، MP3 و JPG
```

در آرشیو پوشه `.git`، `package.json`، ابزار Build، پوشه تست، Migration دیتابیس یا فایل تنظیمات Supabase وجود ندارد. بنابراین تاریخچه Commit و شاخه Git از روی همین آرشیو قابل بررسی نیست.

## 3. معماری فعلی

```text
Browser
  └── index.html (ساختار و صفحات)
      ├── CSS و Design Tokens
      ├── JavaScript اصلی و افزونه‌های UI
      ├── localStorage
      │   ├── وظایف و هدف
      │   ├── Planner
      │   ├── امور مالی
      │   ├── تنظیمات و آمار تمرکز
      │   └── تنظیمات کمکی رابط کاربری
      ├── IndexedDB: PromptVaultDB
      │   ├── prompts
      │   ├── tags
      │   └── meta
      └── فایل‌های محلی تصویر، فونت، آیکون و موسیقی
```

در کد پروژه نشانه‌ای از موارد زیر پیدا نشد:

- Supabase، Firebase یا Backend API
- احراز هویت ایمیل یا Google OAuth
- `user_id` یا جداسازی داده بر اساس حساب کاربری
- `devices`، Outbox، Sync Queue یا Sync Metadata
- `updated_at` و `deleted_at` استاندارد برای رکوردهای اصلی
- `navigator.onLine` یا مدیریت رویدادهای آنلاین/آفلاین
- Service Worker، فایل `sw.js` یا Manifest استاندارد PWA
- درخواست `fetch`، WebSocket یا API خارجی برای داده‌های اصلی

`ASSET-MANIFEST.json` فهرست دارایی‌های پروژه است و جایگزین `manifest.webmanifest` مخصوص PWA نیست.

## 4. فناوری‌ها و وابستگی‌های شناسایی‌شده

| لایه | وضعیت فعلی |
|---|---|
| رابط | HTML، CSS و JavaScript معمولی؛ بدون React/Vue |
| ساختار صفحه | یک HTML اصلی با چند صفحه داخلی و ناوبری سمت‌کاربر |
| استایل | یک CSS اصلی بزرگ و پنج فایل تکمیلی/Override |
| انیمیشن | GSAP محلی در `inline-002.js` به‌همراه فایل‌های Motion |
| آیکون | Lucide محلی در `inline-016.js` و SVG Symbolهای داخل HTML |
| ذخیره‌سازی اصلی | `localStorage` |
| ذخیره‌سازی PromptVault | IndexedDB، با fallback به `localStorage` |
| داده ابری | وجود ندارد |
| نصب PWA | هنوز کامل نشده است |
| Build | وجود ندارد؛ پروژه به‌صورت فایل استاتیک اجرا می‌شود |

فایل‌های JavaScript از نوع Classic Script هستند و به ترتیب قرارگیری در `index.html` وابستگی دارند. `inline-001.js` برای اعمال تم و زبان پیش از نمایش اولیه به‌صورت زودهنگام اجرا می‌شود؛ بخش زیادی از اسکریپت‌های بعدی با `defer` بارگذاری شده‌اند. بنابراین جابه‌جایی یا تبدیل شتاب‌زده آن‌ها به ES Module می‌تواند ترتیب اجرا و دسترسی به متغیرهای سراسری را مختل کند.

## 5. فهرست قابلیت‌های فعلی

| صفحه / قابلیت | آنچه در کد فعلی وجود دارد | وضعیت داده |
|---|---|---|
| Home / Tasks | افزودن، ویرایش، حذف و تکمیل وظیفه؛ تاریخ؛ دسته‌بندی؛ اولویت؛ علامت‌گذاری | آرایه وظایف در `localStorage` |
| Calendar | نمایش ماه‌ها، حرکت بین ماه‌ها، انتخاب روز و نمایش وظایف همان روز | رویداد مستقل ندارد؛ از تاریخ وظایف استفاده می‌کند |
| Progress | نرخ تکمیل وظایف، هدف اصلی، نمودار زمان تمرکز و Heatmap | از وظایف و آمار تمرکز محاسبه می‌شود |
| Stats | نمایش همه، تکمیل‌شده و باقی‌مانده | مشتق‌شده از وظایف |
| Pomodoro / Focus Timer | زمان تمرکز و استراحت، شروع/مکث/ادامه/بازنشانی، ثبت جلسات و زمان تمرکز | زمان تمرکز و شمار جلسات روزانه ذخیره می‌شوند؛ وضعیت لحظه‌ای تایمر در حافظه اجراست |
| Planner | پروژه‌ها، Bucketها، وضعیت، اولویت، چک‌لیست، پیوندها و نماهای Table / Board / Week / Charts | چند کلید مستقل `localStorage`؛ مستقل از وظایف Home |
| Finance | درآمد ماهانه، هزینه/درآمد، دسته‌بندی، تراکنش، تاریخچه ماهانه و ارز | `localStorage` |
| Music | فهرست موسیقی، پخش، جابه‌جایی قطعه، تکرار، Sleep Timer و کنترل صدا | فایل‌های صوتی محلی؛ برخی تنظیمات/مدت‌زمان ذخیره می‌شوند، وضعیت پخش فعلی پایدار نیست |
| Bonfire / PromptVault | ساخت و ویرایش Prompt، Tag، تصویر، علاقه‌مندی، مرتب‌سازی، جست‌وجو و Grid/List | IndexedDB جداگانه و Backup مستقل |
| Settings | زبان، تم، پالت رنگ، عملکرد/انیمیشن، صدا و تنظیمات مالی | چند کلید پراکنده در `localStorage` |
| Search | جست‌وجوی وظایف و محتوای موجود در برنامه | عمدتاً جست‌وجو روی داده‌های محلی |
| Widget preview | انتخاب چیدمان‌های نمایشی ویجت؛ تلاش برای اتصال به API محیط AppMint | در مرورگر عادی صرفاً پیش‌نمایش است؛ ویجت Native به محیط اندرویدی پشتیبانی‌شده نیاز دارد |

### نکات مهم درباره قابلیت‌هایی که در Roadmap آمده‌اند

- **Calendar Events:** صفحه Calendar فعلی سیستم مستقل رویداد ندارد؛ وظایف تاریخ‌دار را در تقویم نشان می‌دهد. Planner نیز مدل جداگانه خود را دارد. جدول `calendar_events` نباید بدون تصمیم محصولی به‌عنوان داده موجود فرض شود.
- **Habits:** ماژول مستقل ساخت/ثبت عادت وجود ندارد. Streak فعلی از روزهایی محاسبه می‌شود که حداقل یک وظیفه تکمیل شده باشد. عبارت Habit در کد فقط در پیش‌نمایش گزینه‌های ویجت دیده می‌شود.
- **Pomodoro Sessions:** رکوردهای مستقل جلسه با شناسه و زمان شروع/پایان وجود ندارند؛ آمار به‌صورت Map روزانه برای ثانیه‌های تمرکز و تعداد جلسات نگهداری می‌شود.
- **Music:** فایل‌های صوتی همراه پروژه هستند؛ لازم نیست خود MP3ها در Sync قرار بگیرند. در صورت نیاز می‌توان ترجیحات قابل انتقال را همگام کرد.

## 6. نقشه ذخیره‌سازی فعلی

### 6.1 هسته اصلی — localStorage

| داده | کلیدهای شناسایی‌شده |
|---|---|
| وظایف | `focusflow-tasks` |
| هدف | `focusflow-primary-goal`، `focusflow-goal-skipped` |
| زمان تمرکز روزانه | `focusflow-focus-seconds-by-day` |
| شمار جلسات روزانه | `focusflow-sessions-by-day` |
| Planner | `focusflow-planner-projects`، `focusflow-planner-active-project`، `focusflow-planner-buckets`، `focusflow-planner-view`، `focusflow-planner-entries` |
| Finance | `focusflow-finance`، `focusflow-finance-monthly-income`، `focusflow-finance-monthly-income-currency`، `focusflow-finance-monthly-income-currency-chosen`، `focusflow-finance-month-history-v1`، checkpointهای ماهانه |
| قفل محلی Finance | `focusflow-finance-password-v1`، `focusflow-finance-security-choice` |
| تنظیمات | `focusflow-theme`، `focusflow-palette`، `focusflow-dark-palette`، `focusflow-language`، `focusflow-sound`، `focusflow-volume`، `focusflow-perf`، `focusflow-perf-detected` |
| تایمر / صدا | `focusflow-custom-minutes`، `focusflow-track-durations` |
| ویجت و UI | `focusflow-native-widget-mode` و کلیدهای کمکی مربوط به موقعیت پنجره شناور |

ذخیره‌ساز عمومی اصلی در `inline-003.js` یک Wrapper کوچک با `get`، `getRaw` و `set` است که مستقیماً از `localStorage` استفاده می‌کند. آرایه‌های بزرگ هر قابلیت عموماً به‌صورت JSON کامل در یک کلید ذخیره می‌شوند.

### 6.2 PromptVault — IndexedDB

پایگاه محلی `PromptVaultDB` با نسخه ۱ ایجاد می‌شود و سه Object Store دارد:

- `prompts`
- `tags`
- `meta`

در صورت نبودن IndexedDB یا بروز خطا، داده‌ها از مسیر جایگزین کلیدهایی مانند `PromptVaultDB:prompts` و `PromptVaultDB:tags` در Local Storage خوانده/نوشته می‌شوند. تصاویر Prompt نیز در همین فضای محلی نگهداری می‌شوند و در رابط کاربری محدودیت اندازه تصویر وجود دارد.

### 6.3 Backup و Restore

Backup اصلی FocusFlow شامل وظایف، Planner، تراکنش‌ها، درآمد ماهانه، تاریخچه ماهانه مالی، هدف و آمار تمرکز است. Import با رویکرد Merge انجام می‌شود و شناسه‌های موجود را دوباره وارد نمی‌کند؛ این رفتار بهتر از Overwrite کور است.

اما Backup اصلی همه داده‌های برنامه را پوشش نمی‌دهد:

1. تنظیمات UI مثل تم، زبان، پالت‌ها و Performance به‌صورت کامل در فایل Backup اصلی نیستند.
2. PromptVault Backup جداگانه دارد و باید جداگانه صادر/بازیابی شود.
3. وضعیت لحظه‌ای پخش موسیقی و تایمر در Backup اصلی نیست.

بنابراین پیش از هر Migration ابری باید یک مسیر Backup جامع و نسخه‌بندی‌شده تهیه شود که هم Backup اصلی و هم PromptVault را پوشش دهد.

## 7. Design System استخراج‌شده

### رنگ و تم

- پس‌زمینه روشن پیش‌فرض: `#e0e5ec`
- سطح اصلی روشن: `#ffffff`
- سطح دوم روشن: `#f4f7fb`
- متن اصلی روشن: `#203d62`
- Accent آبی: `#4f97f5`
- پس‌زمینه تاریک: `#101722`
- سطح تاریک: `#182332` و `#1d2a3b`
- تم اصلی بر پایه Neumorphism با سایه‌های دوطرفه و حالت Inset است.
- هفت پالت روشن و هفت پالت تاریک در منطق برنامه تعریف شده‌اند.
- شعاع‌های اصلی: `24px`، `18px` و `12px`.

### تایپوگرافی و آیکون

- فایل فونت محلی فارسی با نام خانواده `Vazir` و فایل فونت انگلیسی `Roboto` وجود دارد.
- `system-ui` نیز در Stack فونت پایه استفاده می‌شود.
- آیکون‌ها از SVG Symbol و Lucide محلی استفاده می‌کنند.

### چیدمان و حرکت

- پوسته اصلی در CSS با عرض محوری موبایل/ستون باریک و قواعد Responsive متعدد طراحی شده و برای دسکتاپ هم تعدیل‌هایی دارد.
- Transitionها و انیمیشن‌های صفحه، تایمر و بخش Bonfire وجود دارند.
- پشتیبانی از `prefers-reduced-motion` در CSS و JavaScript دیده می‌شود.
- `backdrop-filter` برای بعضی لایه‌ها و Overlayها استفاده شده، اما در پروژه نام/تنظیم مستقل و قابل انتخابی برای **Glass Mode** پیدا نشد. تاری بعضی سطوح معادل وجود یک حالت شیشه‌ای مستقل در Design System نیست.

### لایه‌بندی CSS

1. `FocusFlow-v71.css`
2. `focusflow.css` — استایل اصلی و بزرگ‌ترین فایل
3. `focusflow-motion-v76.css`
4. `focusflow-bonfire-widgets-motion-v77.css`
5. `ff-v78-distinct-widget-themes.css`
6. `ff-native-widgets-style.css`

برای حفظ ظاهر، بهتر است استایل صفحات حساب و Sync در یک فایل افزوده مستقل نوشته شود و در CSS اصلی بازنویسی گسترده انجام نشود.

## 8. شکاف‌ها و ریسک‌های مهم برای Cloud / Offline-First

### ریسک‌های داده و Migration

1. داده‌های فعلی `user_id` ندارند؛ داده‌ها به Origin مرورگر وابسته‌اند، نه حساب کاربری.
2. شناسه‌های مدل‌ها یکسان نیستند: Task شناسه عددی دارد، اما Planner و برخی رکوردهای دیگر از شناسه رشته‌ای استفاده می‌کنند.
3. برای اکثر رکوردهای اصلی `updated_at`، `deleted_at` و `version` استاندارد وجود ندارد.
4. حذف‌ها Hard Delete هستند؛ Tombstone یا تاریخچه حذف برای Sync وجود ندارد.
5. زمان ایجاد واقعی بسیاری از Taskهای قدیمی ثبت نشده است؛ در Migration نباید زمان ساخت تاریخی جعلی ایجاد شود.
6. داده‌های اصلی در Local Storage به‌صورت آرایه/Map ذخیره می‌شوند؛ برای Sync هم‌زمان چند دستگاهی باید به Repository و رکوردهای مستقل تبدیل شوند.
7. کلیدهای Local Storage در سطح Origin هستند. انتقال از `file://`، localhost یا دامنه قدیمی به دامنه Cloudflare نیازمند فرآیند Import/Migration صریح است.
8. PromptVault جدا از هسته اصلی ذخیره می‌شود و فایل‌های تصویری آن ممکن است به Supabase Storage نیاز داشته باشند.

### ریسک‌های امنیتی

- قفل Finance یک قفل محلی رابط کاربری است، نه احراز هویت حساب و نه رمزنگاری داده‌های مالی.
- در صورت وجود Web Crypto، Hash رمز Finance با PBKDF2/SHA-256 ساخته می‌شود؛ اما در مسیر جایگزین، الگوریتم Hash ساده و ضعیف‌تری وجود دارد.
- خود تراکنش‌های مالی در Local Storage به‌صورت داده قابل خواندن ذخیره می‌شوند؛ نباید این قفل به‌عنوان Encryption-at-Rest یا حفاظت سروری تلقی شود.
- Secret سروری در Frontend وجود ندارد؛ در پیاده‌سازی آینده نیز فقط کلید عمومی قابل استفاده در Client قرار می‌گیرد و Service Role باید سمت سرور بماند.

### ریسک‌های عملکردی و معماری

- Core App در `inline-003.js` متمرکز است و چند فایل Patch/Override برای UI و ترجمه روی آن سوار شده‌اند.
- ترتیب اسکریپت‌ها مهم است؛ بازنویسی ساختار یا جابه‌جایی Scriptها بدون تست می‌تواند وابستگی‌های سراسری را بشکند.
- `inline-017.js` پایگاه داده و چرخه ذخیره PromptVault را به‌صورت جدا مدیریت می‌کند؛ باید برای همگام‌سازی آن Adapter مستقل در نظر گرفت.
- وجود `localStorage` به معنی کارکرد تضمین‌شده پس از قطع اینترنت نیست؛ بدون Service Worker و App Shell Cache، بارگذاری فایل‌های برنامه پس از قطع شبکه تضمین نشده است.

## 9. نتیجه بررسی ایستا و کیفیت

بررسی ایستا روی نسخه استخراج‌شده انجام شد:

| کنترل | نتیجه |
|---|---|
| بررسی نحوی JavaScript با `node --check` | ۴۶ فایل بررسی شد؛ صفر خطای Syntax |
| Parse فایل‌های CSS با `tinycss2` | ۶ فایل بررسی شد؛ صفر خطای Parse |
| شناسه‌های HTML | ۴۳۷ شناسه؛ شناسه تکراری پیدا نشد |
| منابع محلی ارجاع‌شده در HTML | مرجع شکسته پیدا نشد |
| URLهای نسبی CSS | ۲ مورد؛ هر دو موجود |
| اجرای تعاملی کامل در مرورگر | در این مرحله اجرا نشده |
| تست واقعی Offline / Sync / OAuth / RLS | اجرا نشده؛ این قابلیت‌ها در نسخه فعلی وجود ندارند |

فایل `QUALITY-REPORT.md` نیز می‌گوید Lighthouse CI برای موبایل و دسکتاپ با حداقل امتیاز ۹۵ تنظیم شده، اما امتیاز واقعی هنوز اندازه‌گیری نشده است. Workflow فعلی در GitHub Actions روی Push، Pull Request و اجرای دستی فعال می‌شود و گزارش‌ها را به‌عنوان Artifact نگه می‌دارد. مقدار ۹۵ در فایل‌ها **آستانه پذیرش** است، نه امتیاز اندازه‌گیری‌شده.

## 10. نقشه تغییرات پیشنهادی فایل‌به‌فایل

این نقشه برای اجرای مراحل بعدی است؛ در Phase 0 هیچ‌کدام از این تغییرات اعمال نشده‌اند.

### فایل‌های موجود که باید با احتیاط توسعه پیدا کنند

| فایل فعلی | نقش فعلی | تغییر پیشنهادی در مراحل بعد |
|---|---|---|
| `index.html` | پوسته و تمام صفحات اصلی | افزودن حداقلی UI ورود/حساب، نشانگر Sync و لینک Manifest؛ بدون بازسازی صفحات موجود |
| `assets/js/inline-001.js` | Bootstrap زودهنگام تم/زبان | حفظ اجرای سریع پیش از Paint؛ خواندن تنظیمات نمایشی از Cache محلی، بدون وابستگی به شبکه |
| `assets/js/inline-003.js` | هسته منطق اصلی، State و ذخیره‌سازی Tasks/Planner/Finance | تغییر محدود برای استفاده از Repository؛ تبدیل مرحله‌ای خواندن/نوشتن Local Storage به API ذخیره‌سازی جدید |
| `assets/js/inline-017.js` | منطق و ذخیره‌سازی PromptVault | حفظ IndexedDB و افزودن Adapter همگام‌سازی Prompt/Tag و تصاویر، بدون حذف مسیر محلی |
| `assets/js/inline-010.js` | پنجره شناور و ذخیره موقعیت آن | ترجیحاً محلی/دستگاه‌محور باقی بماند؛ Sync فقط در صورت تصمیم محصولی |
| `assets/js/ff-native-widgets-integration.js` | پیش‌نمایش و اتصال اختیاری AppMint | حفظ رفتار فعلی؛ فقط در صورت نیاز به حساب کاربری از APIهای مجاز داده بخواند |
| `assets/css/focusflow.css` و پنج CSS دیگر | Design System و لایه‌های فعلی | حفظ به‌عنوان Baseline؛ از بازنویسی گسترده پرهیز شود |
| `README.md` | راهنمای اجرای فعلی | افزودن راهنمای محیط، Supabase، متغیرها، Migration و Deploy |
| `.gitignore` | نادیده‌گرفتن فایل‌های محیطی و خروجی‌ها | حفظ قواعد فعلی؛ افزودن فایل‌های محلی جدید در صورت نیاز |
| `.github/workflows/lighthouse.yml` | کنترل Lighthouse | حفظ؛ افزودن Workflow جدا برای Syntax، Unit و E2E Test |

### فایل‌ها و ماژول‌های جدید پیشنهادی

```text
assets/
├── css/
│   └── focusflow-cloud.css              # فقط استایل Auth و Sync هماهنگ با Design System
├── icons/
│   ├── focusflow-192.png                # آیکون نصب PWA
│   └── focusflow-512.png
└── js/
    └── cloud/
        ├── config.js                    # Supabase URL و anon key از Runtime Config
        ├── auth/
        │   ├── auth.service.js           # Email/Password و Google OAuth
        │   └── session.service.js        # Session و خروج دستگاه‌ها
        ├── database/
        │   ├── local.database.js         # IndexedDB/Dexie و Schema Version
        │   ├── local.repository.js        # Repository داده‌های محلی
        │   └── cloud.repository.js       # دسترسی کنترل‌شده به PostgreSQL
        ├── sync/
        │   ├── sync.engine.js            # Pull/Push و چرخه Sync
        │   ├── sync.queue.js             # Outbox و Retry
        │   ├── sync.conflicts.js         # تشخیص و حل تعارض
        │   └── sync.status.js            # وضعیت قابل نمایش Sync
        └── migration/
            ├── legacy-reader.js          # خواندن کلیدهای فعلی Local Storage
            ├── legacy-migrator.js        # انتقال idempotent به IndexedDB
            └── backup-validator.js       # اعتبارسنجی Backup قبل از Import

manifest.webmanifest                     # Manifest واقعی PWA
service-worker.js                         # Cache App Shell و Offline Fallback
.env.example                              # فقط نام متغیرها، بدون Secret
supabase/
└── migrations/
    ├── 001_initial_schema.sql
    ├── 002_rls_policies.sql
    └── 003_sync_support.sql
 tests/
 ├── unit/
 ├── integration/
 └── e2e/
```

در صورت نیاز به Bundle کردن وابستگی‌ها، `package.json` و Lockfile اضافه می‌شوند؛ اما افزودن Build System باید تصمیم فنی مستقل باشد. تا وقتی امکان اجرای پروژه استاتیک حفظ می‌شود، نباید فقط برای اضافه‌کردن چند ماژول، ابزار ساخت سنگین وارد کرد.

## 11. پیشنهاد تطبیق مدل Cloud با داده واقعی

به‌جای ساختن جداول صرفاً بر مبنای فهرست اولیه Roadmap، مدل اولیه باید از موجودیت‌های واقعی برنامه ساخته شود:

| موجودیت Cloud پیشنهادی | منبع فعلی |
|---|---|
| `tasks` | `focusflow-tasks` |
| `planner_projects` | `focusflow-planner-projects` |
| `planner_buckets` | `focusflow-planner-buckets` |
| `planner_entries` | `focusflow-planner-entries` |
| `finance_transactions` | `focusflow-finance` |
| `finance_settings` | درآمد ماهانه، ارز، انتخاب ارز و تاریخچه ماهانه |
| `daily_focus_stats` | Map ثانیه‌های تمرکز و تعداد جلسات روزانه |
| `user_settings` | تم، پالت، زبان و تنظیمات قابل انتقال |
| `promptvault_prompts` و `promptvault_tags` | Object Storeهای PromptVault |
| `devices` | موجودیت جدید برای مدیریت دستگاه‌های حساب |
| `sync_operations` | موجودیت جدید برای Outbox، Idempotency و وضعیت Sync |

`calendar_events` یا `habits` فقط زمانی به‌عنوان جدول مستقل اضافه شوند که قابلیت محصولی مستقل آن‌ها تعریف و پیاده‌سازی شود. اگر هدف، ثبت رویدادهای تقویمی مستقل از وظایف است، این یک توسعه قابلیت جدید است، نه Migration مستقیم از داده فعلی.

برای رکوردهای قدیمی باید شناسه فعلی حفظ یا به‌شکل قابل بازگشت نگاشت شود؛ به‌خصوص شناسه‌های عددی وظایف نباید در مهاجرت اولیه به‌صورت غیرقابل‌بازگشت عوض شوند. Metadata جدید مثل `version` و `updated_at` باید از این پس ایجاد شود. زمان‌های ایجاد تاریخی که در داده فعلی وجود ندارند نباید به‌عنوان واقعیت جعل شوند.

## 12. برنامه اجرای مرحله‌ای بعد از Phase 0

1. **Phase 1 — حفاظت داده و پایه Auth:** تعریف Backup جامع، مسیر ورود، رفتار حساب مهمان/داده محلی و سیاست Merge قبل از Sync.
2. **Phase 2 — Cloud Schema و RLS:** ساخت جداول منطبق با مدل واقعی، Migration SQL و تست جداسازی دو حساب.
3. **Phase 3 — Local Database:** ایجاد IndexedDB/Dexie برای داده‌های اصلی و مهاجرت idempotent از کلیدهای قدیمی؛ Local Storage کوچک برای Bootstrap نمایشی حفظ شود.
4. **Phase 4 — Repository Adapter:** اتصال تدریجی Tasks، Planner، Finance و سپس PromptVault به Repository جدید؛ UI نباید مستقیم به جزئیات Supabase وابسته شود.
5. **Phase 5 — Sync Engine:** Outbox، شناسه عملیات، Retry، Tombstone، Version و Conflict Resolution؛ ابتدا Sync دستی/کنترل‌شده و سپس Auto Sync.
6. **Phase 6 — PWA:** Manifest، Service Worker، Cache App Shell، Offline Fallback و مدیریت به‌روزرسانی.
7. **Phase 7 — Account & Sync UI:** صفحات ورود و حساب و نشانگرهای همگام‌سازی در سبک فعلی.
8. **Phase 8 — QA و Security:** تست چند حساب، چند دستگاه، قطع اینترنت، بازیابی، RLS، Session و Regression تمام امکانات موجود.
9. **Phase 9 — Deployment:** تنظیم Supabase، GitHub و Cloudflare Pages، متغیرهای محیطی و مستندات انتشار.

## 13. گیت‌های ضروری قبل از شروع Phase 1

1. از داده واقعی مرورگر کاربر Backup گرفته شود؛ آرشیو کد به‌تنهایی حاوی داده‌های Local Storage یا IndexedDB دستگاه نیست.
2. خروجی Backup اصلی و PromptVault جداگانه اعتبارسنجی و نگهداری شود.
3. برای اولین ورود، یک انتخاب روشن نمایش داده شود: ادغام داده محلی فعلی با حساب یا شروع بدون انتقال؛ هیچ داده‌ای خودکار حذف نشود.
4. سیاست حساب‌های متعدد روی یک دستگاه مشخص شود؛ داده محلی هر حساب باید Namespace جداگانه داشته باشد.
5. قفل محلی Finance از Authentication حساب جدا بماند و Hash قفل محلی به‌عنوان رمز حساب یا Encryption تلقی نشود.
6. قبل از فعال‌کردن Google OAuth باید دامنه نهایی و Redirect URLها در Supabase و Google Console مشخص شوند.
7. هیچ تغییر گسترده‌ای روی UI یا فایل‌های اصلی پیش از داشتن نسخه پشتیبان و Regression Test انجام نشود.

---

## جمع‌بندی Phase 0

- ساختار و کد آرشیو بررسی شد.
- قابلیت‌ها و مسیر ذخیره‌سازی فعلی شناسایی شدند.
- Design System و فایل‌های اصلی آن استخراج شدند.
- نبود Auth، Cloud DB، Sync Engine و Service Worker در نسخه فعلی تأیید شد.
- شکاف‌های مدل داده و ریسک‌های Migration مشخص شدند.
- نقشه تغییر فایل‌های موجود و ساختار پیشنهادی فایل‌های جدید تهیه شد.
- بررسی ایستای Syntax JavaScript و Parse CSS موفق بود.
- هیچ فایل اصلی پروژه تغییر نکرد.
- تست تعاملی مرورگر، OAuth، RLS، Offline و Sync عمداً به مراحل بعد موکول‌اند و در این گزارش موفق اعلام نشده‌اند.

**پیشنهاد اجرایی:** Phase 1 نباید با اتصال مستقیم Supabase به توابع فعلی آغاز شود. ابتدا باید Backup جامع و Migration محلی قابل بازگشت طراحی شود؛ سپس Repository Adapter افزوده شود تا FocusFlow فعلی با کمترین تغییر ظاهری و رفتاری به معماری جدید منتقل شود.
