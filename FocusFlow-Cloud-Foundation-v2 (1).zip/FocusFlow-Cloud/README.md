# FocusFlow

FocusFlow is a personal productivity app built to make everyday planning and task management easier.

I created this project to bring different productivity tools together in one place, so users can organize their tasks, plan their schedules, track their progress, and manage their focus without switching between multiple apps.

## Features

- **Tasks:** Create, organize, and manage daily tasks.
- **Calendar:** Keep track of schedules and upcoming activities.
- **Progress:** View completed tasks and monitor productivity.
- **Pomodoro:** Use focused work sessions to manage your time.
- **Planner:** Organize plans and stay on track.
- **Music:** A dedicated section for focus and productivity music.
- **Bonfire:** Save and organize useful prompts in one place.
- **Customization:** Personalize themes, colors, and preferences.
- **Language Support:** Switch between English and Persian.
- **Responsive Design:** Works on desktop and mobile screens.

## Built With

- HTML
- CSS
- JavaScript

## Getting Started

You can run FocusFlow locally without installing additional tools.

1. Clone this repository:

   ```bash
   git clone https://github.com/PooyaRahmany/FocusFlow.git
   ```

2. Open the project folder.
3. Open the main HTML file in your browser.

## About This Project

FocusFlow is an ongoing project. I'm continuously working on improving its design, usability, and features.

The goal is to build a practical and enjoyable workspace for managing everyday tasks and staying focused.

## Author

**Pooya Rahmani**

GitHub: [@PooyaRahmany](https://github.com/PooyaRahmany)

---

**FocusFlow** – Stay organized. Stay focused.

## Offline and PWA foundation

FocusFlow now includes a first-party PWA manifest, matching app icons, a service worker, and a non-destructive IndexedDB mirror for the existing `focusflow-*` LocalStorage data. The original pages, theme system, and app logic remain in place.

For service-worker and install testing, serve the project through HTTPS or `localhost` rather than opening `index.html` directly:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`. See [`docs/CLOUD-FOUNDATION.md`](docs/CLOUD-FOUNDATION.md) and [`CLOUD-IMPLEMENTATION-STATUS.md`](CLOUD-IMPLEMENTATION-STATUS.md) for the exact scope and remaining setup steps.


## Foundation v2 changes (2026-11-11)

- Fixed IndexedDB mirror replacement for updated LocalStorage keys.
- Made the mirror flush queue recover after a failed operation.
- Restricted direct writes to `sync_records`; writes must pass through the version-checked RPC.
- Added a forward SQL migration for existing Supabase projects.

See [`QA-REPORT.md`](QA-REPORT.md) and [`CLOUD-IMPLEMENTATION-STATUS.md`](CLOUD-IMPLEMENTATION-STATUS.md) for verified checks and remaining release gates.
