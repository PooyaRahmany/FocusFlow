/* FocusFlow Offline Foundation — native IndexedDB, no runtime dependency. */
(function () {
  'use strict';

  if (window.FocusFlowLocalDB) return;

  const DB_NAME = 'FocusFlowOfflineDB';
  const DB_VERSION = 1;
  const LOCAL_USER_ID = 'local';
  const PREFIX = 'focusflow-';
  let databasePromise;
  let isRestoring = false;
  const pendingMirrors = new Map();
  let mirrorFlush = Promise.resolve();

  const COLLECTION_BY_KEY = [
    [/^focusflow-tasks$/, 'tasks'],
    [/^focusflow-planner-projects$/, 'planner_projects'],
    [/^focusflow-planner-buckets$/, 'planner_buckets'],
    [/^focusflow-planner-entries$/, 'planner_entries'],
    [/^focusflow-finance$/, 'finance_transactions'],
    [/^focusflow-finance-/, 'finance_settings'],
    [/^focusflow-focus-seconds-by-day$/, 'daily_focus_stats'],
    [/^focusflow-sessions-by-day$/, 'daily_focus_stats'],
    [/^focusflow-track-durations$/, 'music_preferences'],
    [/^focusflow-(theme|palette|dark-palette|language|sound|volume|perf|perf-detected)$/, 'user_settings']
  ];

  function collectionFor(key) {
    const match = COLLECTION_BY_KEY.find(([pattern]) => pattern.test(key));
    return match ? match[1] : 'app_state';
  }

  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB request failed'));
    });
  }

  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error || new Error('IndexedDB transaction failed'));
      transaction.onabort = () => reject(transaction.error || new Error('IndexedDB transaction aborted'));
    });
  }

  function open() {
    if (databasePromise) return databasePromise;
    databasePromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB is not available in this browser context'));
        return;
      }
      let request;
      try { request = indexedDB.open(DB_NAME, DB_VERSION); }
      catch (error) { reject(error); return; }
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('legacy_kv')) {
          const store = db.createObjectStore('legacy_kv', { keyPath: 'key' });
          store.createIndex('updatedAt', 'updatedAt');
        }
        if (!db.objectStoreNames.contains('records')) {
          const store = db.createObjectStore('records', { keyPath: 'id' });
          store.createIndex('userId', 'userId');
          store.createIndex('collection', 'collection');
          store.createIndex('sourceStorageKey', 'sourceStorageKey');
          store.createIndex('updatedAt', 'updatedAt');
        }
        if (!db.objectStoreNames.contains('outbox')) {
          const store = db.createObjectStore('outbox', { keyPath: 'opId' });
          store.createIndex('userId', 'userId');
          store.createIndex('status', 'status');
          store.createIndex('createdAt', 'createdAt');
        }
        if (!db.objectStoreNames.contains('sync_state')) db.createObjectStore('sync_state', { keyPath: 'key' });
        if (!db.objectStoreNames.contains('migration_runs')) db.createObjectStore('migration_runs', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('device_meta')) db.createObjectStore('device_meta', { keyPath: 'key' });
        if (!db.objectStoreNames.contains('conflicts')) {
          const store = db.createObjectStore('conflicts', { keyPath: 'id' });
          store.createIndex('userId', 'userId');
          store.createIndex('createdAt', 'createdAt');
        }
      };
      request.onsuccess = () => {
        const db = request.result;
        db.onversionchange = () => db.close();
        resolve(db);
      };
      request.onerror = () => reject(request.error || new Error('Could not open FocusFlow local database'));
      request.onblocked = () => reject(new Error('FocusFlow local database upgrade is blocked by another open tab'));
    });
    return databasePromise;
  }

  function idFor(collection, recordId) {
    return `${LOCAL_USER_ID}:${collection}:${String(recordId)}`;
  }

  function createRecordRows(key, rawValue, updatedAt) {
    const collection = collectionFor(key);
    let value;
    try { value = JSON.parse(rawValue); }
    catch { value = rawValue; }

    let entries;
    if (Array.isArray(value)) {
      entries = value.map((item, index) => [
        item && (item.id !== undefined && item.id !== null) ? String(item.id) : `${key}:${index}`,
        item
      ]);
    } else if ((key === 'focusflow-focus-seconds-by-day' || key === 'focusflow-sessions-by-day') && value && typeof value === 'object') {
      entries = Object.entries(value).map(([day, item]) => [`${day}:${key === 'focusflow-focus-seconds-by-day' ? 'focus' : 'sessions'}`, {
        day,
        [key === 'focusflow-focus-seconds-by-day' ? 'focusSeconds' : 'sessions']: item
      }]);
    } else {
      entries = [[key, value]];
    }

    return entries.map(([recordId, payload]) => ({
      id: idFor(collection, recordId),
      userId: LOCAL_USER_ID,
      collection,
      recordId: String(recordId),
      payload,
      version: 1,
      clientUpdatedAt: updatedAt,
      updatedAt,
      deletedAt: null,
      sourceStorageKey: key,
      source: 'legacy-localstorage'
    }));
  }

  async function mirrorStorageValue(key, rawValue, deleted) {
    if (!String(key).startsWith(PREFIX) || isRestoring) return;
    const db = await open();
    const now = new Date().toISOString();
    const tx = db.transaction(['legacy_kv', 'records'], 'readwrite');
    const kv = tx.objectStore('legacy_kv');
    const records = tx.objectStore('records');
    const previous = records.index('sourceStorageKey').openCursor(IDBKeyRange.only(String(key)));

    kv.put({
      key: String(key),
      value: deleted ? null : String(rawValue),
      deleted: Boolean(deleted),
      updatedAt: now,
      source: 'localStorage-mirror'
    });

    previous.onsuccess = () => {
      const cursor = previous.result;
      if (cursor) {
        if (deleted) {
          const row = cursor.value;
          row.deletedAt = now;
          row.updatedAt = now;
          row.version = Number(row.version || 1) + 1;
          cursor.update(row);
        } else {
          // Remove the previous snapshot rows, then write the complete new
          // snapshot only after the cursor has finished. Writing only when the
          // first cursor is empty silently dropped every subsequent update.
          cursor.delete();
        }
        cursor.continue();
        return;
      }

      if (!deleted) {
        createRecordRows(String(key), String(rawValue), now).forEach(row => records.put(row));
      }
    };

    await transactionDone(tx);
  }

  function queueMirror(key, value, deleted) {
    if (!String(key).startsWith(PREFIX) || isRestoring) return;
    pendingMirrors.set(String(key), { value: value == null ? null : String(value), deleted: Boolean(deleted) });
    mirrorFlush = mirrorFlush.catch(() => {}).then(async () => {
      const entries = Array.from(pendingMirrors.entries());
      pendingMirrors.clear();
      for (const [entryKey, entry] of entries) {
        try { await mirrorStorageValue(entryKey, entry.value, entry.deleted); }
        catch (error) { console.warn('[FocusFlow] Local IndexedDB mirror deferred:', error); }
      }
    });
  }

  function installStorageMirror() {
    if (!window.Storage || Storage.prototype.__focusFlowMirrorInstalled) return;
    const proto = Storage.prototype;
    const originalSetItem = proto.setItem;
    const originalRemoveItem = proto.removeItem;
    const originalClear = proto.clear;

    proto.setItem = function (key, value) {
      const result = originalSetItem.call(this, key, value);
      if (this === window.localStorage) queueMirror(String(key), String(value), false);
      return result;
    };
    proto.removeItem = function (key) {
      const result = originalRemoveItem.call(this, key);
      if (this === window.localStorage) queueMirror(String(key), null, true);
      return result;
    };
    proto.clear = function () {
      let keys = [];
      if (this === window.localStorage) {
        try { keys = Array.from({ length: this.length }, (_, index) => this.key(index)).filter(Boolean); }
        catch (_) { keys = []; }
      }
      const result = originalClear.call(this);
      if (this === window.localStorage) keys.forEach(key => queueMirror(key, null, true));
      return result;
    };
    Object.defineProperty(proto, '__focusFlowMirrorInstalled', { value: true, configurable: false });
  }

  async function getOne(storeName, key) {
    const db = await open();
    const tx = db.transaction(storeName, 'readonly');
    const done = transactionDone(tx);
    const result = await requestResult(tx.objectStore(storeName).get(key));
    await done;
    return result;
  }

  async function hydrateAndMigrateLegacyStorage() {
    // Read first, then write in a separate transaction. IndexedDB transactions
    // are intentionally never held open across unrelated async work.
    const storedRows = await getAll('legacy_kv');
    const previousRun = await getOne('migration_runs', 'legacy-localstorage-v1');
    const storedByKey = new Map(storedRows.map(row => [row.key, row]));
    let recoverable = 0;
    let discovered = 0;
    // Never restore asynchronously during app startup: core app state is read
    // by legacy scripts immediately after this deferred file. Recovery is an
    // explicit action followed by a reload, so no running state is overwritten.
    for (const [key, row] of storedByKey) {
      if (!key.startsWith(PREFIX) || row.deleted) continue;
      let current = null;
      try { current = localStorage.getItem(key); } catch (_) {}
      if (current === null && typeof row.value === 'string') recoverable += 1;
    }

    const discoveredRows = [];
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (!key || !key.startsWith(PREFIX)) continue;
      const current = localStorage.getItem(key);
      const known = storedByKey.get(key);
      if (!known || known.deleted || known.value !== current) {
        discoveredRows.push({ key, value: current, deleted: false, updatedAt: new Date().toISOString(), source: 'legacy-import' });
        discovered += 1;
      }
    }

    const run = {
      id: 'legacy-localstorage-v1',
      schemaVersion: 1,
      completedAt: new Date().toISOString(),
      discoveredKeys: discovered,
      recoverableKeys: recoverable,
      restoredKeys: 0,
      previouslyCompletedAt: previousRun && previousRun.completedAt || null,
      nonDestructive: true
    };
    const db = await open();
    const tx = db.transaction(['legacy_kv', 'migration_runs'], 'readwrite');
    const done = transactionDone(tx);
    const kv = tx.objectStore('legacy_kv');
    discoveredRows.forEach(row => kv.put(row));
    tx.objectStore('migration_runs').put(run);
    await done;

    // Ensure every discovered value has a normalized local record snapshot.
    const allKeys = [];
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (key && key.startsWith(PREFIX)) allKeys.push(key);
    }
    for (const key of allKeys) {
      try { await mirrorStorageValue(key, localStorage.getItem(key), false); }
      catch (error) { console.warn('[FocusFlow] Could not mirror legacy key:', key, error); }
    }

    return { available: true, ...run };
  }

  async function getAll(storeName) {
    const db = await open();
    const tx = db.transaction(storeName, 'readonly');
    const done = transactionDone(tx);
    const result = await requestResult(tx.objectStore(storeName).getAll());
    await done;
    return result;
  }

  async function getCollection(collection, options = {}) {
    const rows = await getAll('records');
    return rows.filter(row => row.collection === collection && row.userId === (options.userId || LOCAL_USER_ID) && (options.includeDeleted || !row.deletedAt));
  }

  async function enqueueOperation(operation) {
    if (!operation || typeof operation !== 'object') throw new TypeError('A sync operation object is required');
    const db = await open();
    const row = {
      ...operation,
      opId: operation.opId || (crypto.randomUUID ? crypto.randomUUID() : `op-${Date.now()}-${Math.random().toString(16).slice(2)}`),
      userId: operation.userId || LOCAL_USER_ID,
      status: operation.status || 'pending',
      createdAt: operation.createdAt || new Date().toISOString(),
      attempts: Number(operation.attempts || 0)
    };
    const tx = db.transaction('outbox', 'readwrite');
    tx.objectStore('outbox').put(row);
    await transactionDone(tx);
    return row;
  }

  async function restoreMissingLegacyStorage() {
    const rows = await getAll('legacy_kv');
    let restored = 0;
    isRestoring = true;
    try {
      for (const row of rows) {
        if (!row.key.startsWith(PREFIX) || row.deleted || typeof row.value !== 'string') continue;
        let current = null;
        try { current = localStorage.getItem(row.key); } catch (_) {}
        if (current === null) {
          try { localStorage.setItem(row.key, row.value); restored += 1; } catch (_) {}
        }
      }
    } finally {
      isRestoring = false;
    }
    return { restored, reloadRequired: restored > 0 };
  }

  async function storageEstimate() {
    if (!navigator.storage || !navigator.storage.estimate) return null;
    try { return await navigator.storage.estimate(); } catch (_) { return null; }
  }

  async function exportLocalSnapshot() {
    const [legacyStorage, records, syncState, migrations] = await Promise.all([
      getAll('legacy_kv'), getAll('records'), getAll('sync_state'), getAll('migration_runs')
    ]);
    return {
      app: 'FocusFlow',
      kind: 'offline-local-snapshot',
      schemaVersion: DB_VERSION,
      exportedAt: new Date().toISOString(),
      note: 'This snapshot preserves the legacy LocalStorage mirror. PromptVault IndexedDB is maintained separately by the existing app.',
      legacyStorage: legacyStorage.filter(row => !row.deleted),
      records: records.filter(row => !row.deletedAt),
      syncState,
      migrations
    };
  }

  installStorageMirror();
  const ready = hydrateAndMigrateLegacyStorage()
    .then(async result => {
      try {
        if (navigator.storage && navigator.storage.persist) {
          window.FocusFlowStoragePersistence = await navigator.storage.persist();
        }
      } catch (_) { window.FocusFlowStoragePersistence = false; }
      window.dispatchEvent(new CustomEvent('focusflow:local-database-ready', { detail: result }));
      return result;
    })
    .catch(error => {
      console.error('[FocusFlow] Offline local database is unavailable; legacy LocalStorage remains active.', error);
      const result = { available: false, error: error.message };
      window.dispatchEvent(new CustomEvent('focusflow:local-database-error', { detail: result }));
      return result;
    });

  window.FocusFlowLocalDB = Object.freeze({
    name: DB_NAME,
    version: DB_VERSION,
    ready,
    open,
    getAll,
    getCollection,
    enqueueOperation,
    restoreMissingLegacyStorage,
    exportLocalSnapshot,
    storageEstimate,
    get pendingMirrorWrites() { return pendingMirrors.size; },
    getLocalStorageSnapshot: () => getAll('legacy_kv')
  });

  window.addEventListener('storage', event => {
    if (event.key && event.key.startsWith(PREFIX)) queueMirror(event.key, event.newValue, event.newValue === null);
    else if (event.key === null) {
      // Another tab cleared storage: retain tombstones rather than silently erasing the local mirror.
      getAll('legacy_kv').then(rows => rows.filter(row => !row.deleted).forEach(row => queueMirror(row.key, null, true))).catch(() => {});
    }
  });
})();
