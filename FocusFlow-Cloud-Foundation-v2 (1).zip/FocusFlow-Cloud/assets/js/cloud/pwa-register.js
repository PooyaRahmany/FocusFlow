/* Register the local app shell cache only on secure origins (HTTPS or localhost). */
(function () {
  'use strict';
  if (!('serviceWorker' in navigator)) return;
  const isLocalhost = ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
  if (!window.isSecureContext && !isLocalhost) return;

  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('./service-worker.js', { scope: './' });
      registration.update().catch(() => {});
      window.dispatchEvent(new CustomEvent('focusflow:pwa-registered', { detail: { scope: registration.scope } }));
    } catch (error) {
      console.warn('[FocusFlow] PWA service worker registration failed:', error);
      window.dispatchEvent(new CustomEvent('focusflow:pwa-error', { detail: { message: error.message } }));
    }
  }, { once: true });
})();
