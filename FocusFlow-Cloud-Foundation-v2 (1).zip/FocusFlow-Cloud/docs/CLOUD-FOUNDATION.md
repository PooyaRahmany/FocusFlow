# FocusFlow Cloud foundation — current implementation

## Product decisions carried into this implementation

- Sign-in target: both email/password and Google OAuth.
- Synchronization target: automatic, bidirectional sync.
- Shared data target: all supported user-owned FocusFlow data; large bundled audio files remain app assets and are not uploaded as user records.

## What is implemented in this package

- A native IndexedDB database (used instead of adding Dexie to this static, dependency-free app) named `FocusFlowOfflineDB` with `legacy_kv`, `records`, `outbox`, `sync_state`, `migration_runs`, `device_meta`, and `conflicts` stores.
- A non-destructive bridge that mirrors existing `focusflow-*` LocalStorage writes into IndexedDB. Missing values are not auto-restored during startup; an explicit recovery helper is available and a reload is required afterward.
- A local record snapshot for the existing Tasks, Planner, Finance, daily focus statistics, UI settings, music preferences, and remaining FocusFlow keys.
- A PWA manifest, matching FocusFlow leaf icons, service worker, application-shell cache, and offline fallback.
- Initial Supabase SQL for profiles, devices, versioned sync records, idempotency operations, per-device sync state, RLS policies, and an atomic version-checked write function.
- A Cloudflare Pages Function that returns only the public Supabase URL and anon/publishable key.

## Important boundaries

- The existing UI still reads/writes LocalStorage. This first pass mirrors those writes to IndexedDB; it does not yet switch every feature to an IndexedDB Repository. This is deliberate to avoid breaking the existing app before regression tests and account migration choices are ready.
- PromptVault continues using its existing `PromptVaultDB` IndexedDB database. Its prompts, tags, and images are not copied into `FocusFlowOfflineDB` by this foundation.
- No account is connected yet. Email/password, Google OAuth, remote push/pull, realtime, and device revocation are not enabled in the UI.
- The SQL migration has been authored but not applied to a real Supabase project. RLS and the RPC must be tested in that project before production use.
- Offline behavior requires serving the app from HTTPS or `localhost`; opening `index.html` as `file://` does not support service workers.

## Run locally

Use a local HTTP server (not `file://`):

```bash
python -m http.server 8080
```

Open `http://localhost:8080`. The service worker should register after the first successful load. The first install attempts to cache all first-party JS/CSS/fonts/media; optional media cache failures do not block installation.

## Local data stores

`window.FocusFlowLocalDB.ready` resolves after the non-destructive legacy snapshot pass.

Useful browser-console checks:

```js
await window.FocusFlowLocalDB.ready
await window.FocusFlowLocalDB.getCollection('tasks')
await window.FocusFlowLocalDB.getLocalStorageSnapshot()
await window.FocusFlowLocalDB.exportLocalSnapshot()
await window.FocusFlowLocalDB.storageEstimate()
await window.FocusFlowLocalDB.restoreMissingLegacyStorage() // reload if restored > 0
```

The `local` user namespace is intentionally separate from future authenticated account namespaces. No local data is automatically uploaded to a cloud account.

## Supabase preparation

1. Create a Supabase project.
2. Review and apply `supabase/migrations/202611100001_initial_cloud_schema.sql` in a non-production project first.
3. Configure email authentication and Google OAuth in Supabase Auth.
4. Configure the Google OAuth consent screen and redirect/callback URLs using the values displayed by your Supabase project.
5. Set `SUPABASE_URL` and `SUPABASE_ANON_KEY` in Cloudflare Pages environment variables. The `/api/config` Function exposes only these public client values.
6. Never expose the Supabase service-role key. RLS must remain enabled.
7. Test RLS with at least two different accounts, including select/insert/update attempts against another user's IDs.

The presence of SQL files does not mean migrations have run or that authentication is working.
