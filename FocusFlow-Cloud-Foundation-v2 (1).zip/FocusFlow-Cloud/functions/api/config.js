/* Cloudflare Pages Function: publish only the Supabase project URL and anon key.
   Never add the Supabase service_role key to this response or to browser code. */
export async function onRequest({ env }) {
  const url = typeof env.SUPABASE_URL === 'string' ? env.SUPABASE_URL.trim() : '';
  const anonKey = typeof env.SUPABASE_ANON_KEY === 'string' ? env.SUPABASE_ANON_KEY.trim() : '';
  const configured = Boolean(url && anonKey && /^https:\/\//i.test(url));
  return new Response(JSON.stringify({ configured, url: configured ? url : null, anonKey: configured ? anonKey : null }), {
    status: 200,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store, max-age=0',
      'x-content-type-options': 'nosniff'
    }
  });
}
