/* FocusFlow PWA shell. Bump CACHE_VERSION whenever shell files change. */
const CACHE_VERSION = 'focusflow-shell-v2';
const SHELL_CACHE = `${CACHE_VERSION}-shell`;
const RUNTIME_CACHE = `${CACHE_VERSION}-runtime`;
const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './assets/css/FocusFlow-v71.css',
  './assets/css/focusflow.css',
  './assets/css/focusflow-motion-v76.css',
  './assets/css/focusflow-bonfire-widgets-motion-v77.css',
  './assets/css/ff-v78-distinct-widget-themes.css',
  './assets/css/ff-native-widgets-style.css',
  './assets/css/focusflow-cloud.css',
  './assets/js/inline-001.js',
  './assets/js/inline-002.js',
  './assets/js/inline-003.js',
  './assets/js/cloud/local-database.js',
  './assets/js/cloud/pwa-register.js',
  './assets/js/focusflow-a11y-fallback.js',
  './assets/js/ff-native-widgets-integration.js',
  './assets/js/focusflow-motion-v76-js.js',
  './assets/js/focusflow-v71-overrides.js',
  './assets/icons/focusflow-192.png',
  './assets/icons/focusflow-512.png'
];
const OPTIONAL_ASSETS = [
  './assets/js/inline-004.js', './assets/js/inline-005.js', './assets/js/inline-006.js',
  './assets/js/inline-007.js', './assets/js/inline-008.js', './assets/js/inline-009.js',
  './assets/js/inline-010.js', './assets/js/inline-011.js', './assets/js/inline-012.js',
  './assets/js/inline-013.js', './assets/js/inline-014.js', './assets/js/inline-015.js',
  './assets/js/inline-016.js', './assets/js/inline-017.js', './assets/js/inline-018.js',
  './assets/js/inline-019.js', './assets/js/inline-020.js', './assets/js/inline-021.js',
  './assets/js/inline-022.js', './assets/js/inline-023.js', './assets/js/inline-024.js',
  './assets/js/inline-025.js', './assets/js/inline-026.js', './assets/js/inline-027.js',
  './assets/js/inline-029.js', './assets/js/inline-030.js', './assets/js/inline-031.js',
  './assets/js/inline-032.js', './assets/js/inline-033.js', './assets/js/inline-034.js',
  './assets/js/inline-035.js', './assets/js/inline-036.js', './assets/js/inline-037.js',
  './assets/js/inline-038.js', './assets/js/inline-039.js', './assets/js/inline-040.js',
  './assets/js/inline-041.js', './assets/js/inline-042.js', './assets/js/inline-043.js',
  './assets/js/focusflow-motion-v76-js.js', './assets/js/focusflow-v71-overrides.js',
  './assets/js/ff-native-widgets-integration.js', './assets/js/focusflow-a11y-fallback.js',
  './assets/fonts/focusflow-font-01.woff2', './assets/fonts/focusflow-font-02.woff2',
  './assets/media/ff-asset-001.jpg', './assets/media/ff-asset-002.jpg',
  './assets/media/ff-asset-003.svg', './assets/media/ff-asset-004.svg', './assets/media/ff-asset-005.svg',
  './assets/media/ff-asset-006.svg', './assets/media/ff-asset-007.svg', './assets/media/ff-asset-008.svg',
  './assets/media/ff-asset-009.svg', './assets/media/ff-asset-010.svg', './assets/media/ff-asset-011.svg',
  './assets/media/ff-asset-012.svg', './assets/media/ff-asset-013.svg', './assets/media/ff-asset-014.svg',
  './assets/media/ff-asset-015.svg', './assets/media/ff-asset-016.svg', './assets/media/ff-asset-017.svg',
  './assets/media/ff-asset-018.svg', './assets/media/ff-asset-019.svg', './assets/media/ff-asset-020.svg',
  './assets/media/ff-asset-021.svg', './assets/media/ff-asset-022.svg', './assets/media/ff-asset-023.svg',
  './assets/media/ff-asset-024.mp3', './assets/media/ff-asset-025.mp3', './assets/media/ff-asset-026.mp3',
  './assets/media/ff-asset-027.mp3', './assets/media/ff-asset-028.svg', './assets/media/ff-asset-029.svg',
  './assets/media/ff-asset-030.svg', './assets/media/ff-asset-031.svg', './assets/media/ff-asset-032.svg',
  './assets/media/ff-asset-033.svg', './assets/media/ff-asset-034.svg', './assets/media/ff-asset-035.svg',
  './assets/media/ff-asset-036.svg', './assets/media/ff-asset-037.svg', './assets/media/ff-asset-038.svg',
  './assets/media/ff-asset-039.svg', './assets/media/ff-asset-040.svg', './assets/media/ff-asset-041.svg',
  './assets/media/ff-asset-042.svg', './assets/media/ff-asset-043.svg', './assets/media/ff-asset-044.svg',
  './assets/media/ff-asset-045.svg', './assets/media/ff-asset-046.svg', './assets/media/ff-asset-047.svg',
  './assets/media/ff-asset-048.svg', './assets/media/ff-asset-049.svg', './assets/media/ff-asset-050.svg',
  './assets/media/ff-asset-051.svg', './assets/media/ff-asset-052.svg', './assets/media/ff-asset-053.svg',
  './assets/media/ff-asset-054.svg', './assets/media/ff-asset-055.svg', './assets/media/ff-asset-056.svg',
  './assets/media/ff-asset-057.svg', './assets/media/ff-asset-058.mp3', './assets/media/ff-asset-059.mp3'
];

function absoluteAssetUrl(asset) {
  return new URL(asset, self.registration.scope).href;
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);
    await Promise.all(CORE_ASSETS.map(async asset => {
      try { await cache.add(new Request(absoluteAssetUrl(asset), { cache: 'reload' })); }
      catch (error) { console.warn('[FocusFlow SW] Core asset could not be cached:', asset, error); }
    }));
    const optionalCache = await caches.open(RUNTIME_CACHE);
    await Promise.all(OPTIONAL_ASSETS.map(async asset => {
      try { await optionalCache.add(new Request(absoluteAssetUrl(asset), { cache: 'reload' })); }
      catch (error) { console.warn('[FocusFlow SW] Optional asset deferred:', asset, error); }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('focusflow-') && ![SHELL_CACHE, RUNTIME_CACHE].includes(name)).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.includes('/api/')) return;

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response && response.ok) {
          const cache = await caches.open(SHELL_CACHE);
          cache.put(absoluteAssetUrl('./index.html'), response.clone()).catch(() => {});
        }
        return response;
      } catch (_) {
        return (await caches.match(request)) || (await caches.match(absoluteAssetUrl('./index.html'))) || Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response && response.ok && response.type === 'basic') {
        const cache = await caches.open(RUNTIME_CACHE);
        cache.put(request, response.clone()).catch(() => {});
      }
      return response;
    } catch (_) {
      return cached || Response.error();
    }
  })());
});
