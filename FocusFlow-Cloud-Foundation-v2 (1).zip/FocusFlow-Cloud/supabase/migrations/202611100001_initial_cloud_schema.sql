-- FocusFlow Cloud — initial schema for the real entities in the existing app.
-- Apply only after creating a Supabase project and reviewing this migration.
-- All user data is isolated by auth.uid(); record writes are version-checked by RPC.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  device_key uuid not null,
  device_name text not null default 'FocusFlow device',
  platform text not null default 'web',
  user_agent text,
  first_seen_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz,
  created_at timestamptz not null default now(),
  unique (user_id, device_key)
);

-- One versioned JSON record per entity. This lets the first migration preserve
-- existing Task/Planner/Finance shapes instead of forcing a destructive rewrite.
create table if not exists public.sync_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  collection text not null check (collection in (
    'tasks', 'planner_projects', 'planner_buckets', 'planner_entries',
    'finance_transactions', 'finance_settings', 'daily_focus_stats',
    'user_settings', 'music_preferences', 'promptvault_prompts',
    'promptvault_tags', 'calendar_events', 'habits', 'app_state'
  )),
  record_id text not null check (length(record_id) between 1 and 240),
  payload jsonb not null default '{}'::jsonb,
  version integer not null default 1 check (version > 0),
  client_updated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (user_id, collection, record_id)
);

create index if not exists sync_records_user_updated_idx
  on public.sync_records (user_id, updated_at desc);
create index if not exists sync_records_user_collection_idx
  on public.sync_records (user_id, collection, record_id);

-- The operation log provides idempotency keys. It intentionally stores metadata,
-- not a second copy of the payload.
create table if not exists public.sync_operations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  operation_id uuid not null,
  device_key uuid,
  collection text not null,
  record_id text not null,
  operation text not null check (operation in ('upsert', 'delete')),
  result_version integer not null,
  applied_at timestamptz not null default now(),
  unique (user_id, operation_id)
);

create index if not exists sync_operations_user_applied_idx
  on public.sync_operations (user_id, applied_at desc);

create table if not exists public.sync_state (
  user_id uuid not null references auth.users(id) on delete cascade,
  device_key uuid not null,
  cursor_updated_at timestamptz,
  last_synced_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, device_key)
);

-- Create a profile whenever Supabase Auth creates a user.
create or replace function public.handle_new_focusflow_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', ''),
    new.raw_user_meta_data ->> 'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

revoke all on function public.handle_new_focusflow_user() from public;

drop trigger if exists on_auth_user_created_focusflow on auth.users;
create trigger on_auth_user_created_focusflow
after insert on auth.users
for each row execute procedure public.handle_new_focusflow_user();

-- Enable Row Level Security on every user-owned table.
alter table public.profiles enable row level security;
alter table public.devices enable row level security;
alter table public.sync_records enable row level security;
alter table public.sync_operations enable row level security;
alter table public.sync_state enable row level security;

-- Profiles: a user can only read and update their own profile.
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (id = (select auth.uid()));
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update to authenticated using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- Devices: a user can manage only their own registered devices.
drop policy if exists "devices_select_own" on public.devices;
create policy "devices_select_own" on public.devices
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "devices_insert_own" on public.devices;
create policy "devices_insert_own" on public.devices
  for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "devices_update_own" on public.devices;
create policy "devices_update_own" on public.devices
  for update to authenticated using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));
drop policy if exists "devices_delete_own" on public.devices;
create policy "devices_delete_own" on public.devices
  for delete to authenticated using (user_id = (select auth.uid()));

-- Records: no hard deletes; use deleted_at as a tombstone.
drop policy if exists "sync_records_select_own" on public.sync_records;
create policy "sync_records_select_own" on public.sync_records
  for select to authenticated using (user_id = (select auth.uid()));
-- Clients may read their own records. Writes are restricted to the
-- version-checked SECURITY DEFINER RPC below; direct table writes are revoked.
drop policy if exists "sync_records_insert_own" on public.sync_records;
drop policy if exists "sync_records_update_own" on public.sync_records;

-- Operation records are append-only and scoped to the owning account.
drop policy if exists "sync_operations_select_own" on public.sync_operations;
create policy "sync_operations_select_own" on public.sync_operations
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "sync_operations_insert_own" on public.sync_operations;
create policy "sync_operations_insert_own" on public.sync_operations
  for insert to authenticated with check (user_id = (select auth.uid()));

-- Each device can read/update only its own cursor.
drop policy if exists "sync_state_select_own" on public.sync_state;
create policy "sync_state_select_own" on public.sync_state
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "sync_state_insert_own" on public.sync_state;
create policy "sync_state_insert_own" on public.sync_state
  for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "sync_state_update_own" on public.sync_state;
create policy "sync_state_update_own" on public.sync_state
  for update to authenticated using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- Atomic, idempotent, version-checked write. A version mismatch is returned as
-- a conflict; the server never silently applies Last-Write-Wins.
create or replace function public.apply_focusflow_sync_operation(
  p_operation_id uuid,
  p_device_key uuid,
  p_collection text,
  p_record_id text,
  p_payload jsonb,
  p_base_version integer,
  p_deleted boolean default false,
  p_client_updated_at timestamptz default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_current_version integer;
  v_result_version integer;
  v_duplicate_version integer;
  v_exists boolean := false;
  v_now timestamptz := now();
begin
  if v_user_id is null then
    raise exception 'Authentication required' using errcode = '28000';
  end if;
  if p_operation_id is null or p_record_id is null or length(p_record_id) not between 1 and 240 then
    raise exception 'Operation ID and record ID (1-240 characters) are required' using errcode = '22023';
  end if;
  if p_collection not in (
    'tasks', 'planner_projects', 'planner_buckets', 'planner_entries',
    'finance_transactions', 'finance_settings', 'daily_focus_stats',
    'user_settings', 'music_preferences', 'promptvault_prompts',
    'promptvault_tags', 'calendar_events', 'habits', 'app_state'
  ) then
    raise exception 'Unsupported FocusFlow collection' using errcode = '22023';
  end if;
  if not p_deleted and p_payload is null then
    raise exception 'Payload is required for upsert' using errcode = '22023';
  end if;

  -- Serialize retries for the same operation and concurrent first writes to the same record.
  perform pg_advisory_xact_lock(hashtextextended(v_user_id::text || ':op:' || p_operation_id::text, 0));
  perform pg_advisory_xact_lock(hashtextextended(v_user_id::text || ':record:' || p_collection || ':' || p_record_id, 0));

  select result_version into v_duplicate_version
  from public.sync_operations
  where user_id = v_user_id and operation_id = p_operation_id;
  if found then
    return jsonb_build_object('ok', true, 'duplicate', true, 'version', v_duplicate_version);
  end if;

  select version into v_current_version
  from public.sync_records
  where user_id = v_user_id
    and collection = p_collection
    and record_id = p_record_id
  for update;
  v_exists := found;
  if not v_exists then v_current_version := 0; end if;

  if coalesce(p_base_version, 0) <> v_current_version then
    return jsonb_build_object(
      'ok', false,
      'conflict', true,
      'expected_version', coalesce(p_base_version, 0),
      'server_version', v_current_version
    );
  end if;

  v_result_version := v_current_version + 1;
  if v_exists then
    update public.sync_records
    set payload = case when p_deleted then payload else p_payload end,
        version = v_result_version,
        client_updated_at = p_client_updated_at,
        updated_at = v_now,
        deleted_at = case when p_deleted then v_now else null end
    where user_id = v_user_id
      and collection = p_collection
      and record_id = p_record_id;
  else
    insert into public.sync_records (
      user_id, collection, record_id, payload, version,
      client_updated_at, created_at, updated_at, deleted_at
    ) values (
      v_user_id, p_collection, p_record_id,
      coalesce(p_payload, '{}'::jsonb), v_result_version,
      p_client_updated_at, v_now, v_now,
      case when p_deleted then v_now else null end
    );
  end if;

  insert into public.sync_operations (
    user_id, operation_id, device_key, collection, record_id, operation, result_version
  ) values (
    v_user_id, p_operation_id, p_device_key, p_collection, p_record_id,
    case when p_deleted then 'delete' else 'upsert' end, v_result_version
  );

  if p_device_key is not null then
    insert into public.sync_state (user_id, device_key, last_synced_at, updated_at)
    values (v_user_id, p_device_key, v_now, v_now)
    on conflict (user_id, device_key)
    do update set last_synced_at = excluded.last_synced_at, updated_at = excluded.updated_at;
  end if;

  return jsonb_build_object('ok', true, 'duplicate', false, 'version', v_result_version);
end;
$$;

revoke all on function public.apply_focusflow_sync_operation(uuid, uuid, text, text, jsonb, integer, boolean, timestamptz) from public;
grant execute on function public.apply_focusflow_sync_operation(uuid, uuid, text, text, jsonb, integer, boolean, timestamptz) to authenticated;

revoke all on table public.profiles, public.devices, public.sync_records, public.sync_operations, public.sync_state from public, anon;
grant select, update on table public.profiles to authenticated;
grant select, insert, update, delete on table public.devices to authenticated;
grant select on table public.sync_records to authenticated;
revoke insert, update, delete, truncate, references, trigger on table public.sync_records from authenticated;
grant select, insert on table public.sync_operations to authenticated;
grant select, insert, update on table public.sync_state to authenticated;
