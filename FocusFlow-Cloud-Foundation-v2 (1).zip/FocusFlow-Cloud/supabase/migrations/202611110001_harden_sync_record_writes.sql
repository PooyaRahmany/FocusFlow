-- FocusFlow Cloud: enforce version-checked writes for sync records.
-- Safe to apply after the initial schema migration, including existing projects.

-- The RPC validates auth.uid() and scopes every read/write by that user. Its
-- fixed search_path and fully-qualified table names prevent object shadowing.
alter function public.apply_focusflow_sync_operation(
  uuid, uuid, text, text, jsonb, integer, boolean, timestamptz
) security definer;

-- Remove direct client-side write paths. Reads remain scoped by RLS.
drop policy if exists "sync_records_insert_own" on public.sync_records;
drop policy if exists "sync_records_update_own" on public.sync_records;
revoke insert, update, delete, truncate, references, trigger
  on table public.sync_records from authenticated;
grant select on table public.sync_records to authenticated;

-- Ensure anonymous/public roles cannot access these records.
revoke all on table public.sync_records from public, anon;
